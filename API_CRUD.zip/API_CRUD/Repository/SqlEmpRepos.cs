﻿using API_CRUD.Model;
using API_CRUD.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace API_CRUD.Repository
{
    public class SqlEmpRepos : IEmployee
    {
        private readonly Appdbcontext context;

        public SqlEmpRepos(Appdbcontext context)
        {
            this.context = context;
        }

        // Add an Employee
        public async Task<ActionResult<Employee>> Add(Employee employee)
        {
            context.Employees.Add(employee);
            await context.SaveChangesAsync();
            return new CreatedAtActionResult("GetEmployee", "Employee", new { id = employee.Id }, employee);
        }

        // Delete an Employee
        public async Task<Employee> Delete(int id)
        {
            var employee = await context.Employees.FindAsync(id);
            if (employee == null)
            {
                return null; // Employee not found
            }

            context.Employees.Remove(employee);
            await context.SaveChangesAsync();
            return employee; // Return the deleted employee
        }

        // Get All Employees
        public async Task<ActionResult<IEnumerable<Employee>>> GetAllEmployee()
        {
            if (context.Employees == null)
            {
                return new NotFoundResult(); // Return NotFound if Employees table is null
            }
            return await context.Employees.ToListAsync();
        }

        // Get Employee by Id
        public async Task<ActionResult<Employee>> GetEmployee(int id)
        {
            var employee = await context.Employees.FindAsync(id);
            if (employee == null)
            {
                return new NotFoundResult(); // Employee not found
            }

            return employee;
        }

        // Update an Employee
       
        public async Task<Employee> Update(int id, Employee employeeChanges)
        {
          

            context.Entry(employeeChanges).State = EntityState.Modified;

            try
            {
                await context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EmployeeExists(id))
                {
                    Console.WriteLine("Employee not found"); // Employee does not exist
                }
                else
                {
                    throw;
                }
            }

            return employeeChanges;
        }

        // Helper method to check if an employee exists
        private bool EmployeeExists(int id)
        {
            return context.Employees.Any(e => e.Id == id);
        }

        
    }
}
