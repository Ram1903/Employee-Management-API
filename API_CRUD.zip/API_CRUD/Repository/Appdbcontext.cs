﻿using API_CRUD.Model;
using Microsoft.EntityFrameworkCore;

namespace API_CRUD.Repository
{
    
        public class Appdbcontext : DbContext
        {
        
        public Appdbcontext(DbContextOptions<Appdbcontext> options)
                     : base(options)
            {
            }
            protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
            {
                if (!optionsBuilder.IsConfigured)
                {
                    optionsBuilder.UseSqlServer(@"Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=DemoDb;Integrated Security=True");
                }
            }
            public DbSet<Employee> Employees { get; set; }
        }
}

